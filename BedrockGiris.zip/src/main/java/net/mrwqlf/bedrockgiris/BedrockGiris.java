/*
 * © MRWQLF (EFEHAN KARACA) TARAFINDAN TELİFLİDİR.
 * Bu kodun izinsiz kopyalanması, dağıtılması veya değiştirilmesi yasaktır.
 */
package net.mrwqlf.bedrockgiris;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer;
import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.plugin.java.JavaPlugin;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

/**
 * Bedrock oyunculari (Geyser + Floodgate) icin ayri, bagimsiz yardimci eklenti.
 * Market/AH sistemiyle hicbir baglantisi yoktur.
 * Bedrock oyuncusu tespiti: Floodgate API (yansima) veya Floodgate UUID bicimi (ilk 64 bit sifir).
 */
// © MRWQLF (EFEHAN KARACA) TARAFINDAN TELİFLİDİR
public final class BedrockGiris extends JavaPlugin implements Listener, CommandExecutor, TabCompleter {

    // © MRWQLF (EFEHAN KARACA) TARAFINDAN TELİFLİDİR
    private static final String ETIKET = "bedrock";

    // © MRWQLF (EFEHAN KARACA) TARAFINDAN TELİFLİDİR
    @Override
    public void onEnable() {
        saveDefaultConfig();
        Bukkit.getPluginManager().registerEvents(this, this);
        var komut = getCommand("bedrock");
        if (komut != null) {
            komut.setExecutor(this);
            komut.setTabCompleter(this);
        }
        getLogger().info("BedrockGiris aktif. Floodgate: " + (floodgateVar() ? "bulundu" : "yok (UUID ile tespit)"));
    }

    // ------------------------------------------------------------ tespit

    // © MRWQLF (EFEHAN KARACA) TARAFINDAN TELİFLİDİR
    private boolean floodgateVar() {
        var pl = Bukkit.getPluginManager().getPlugin("floodgate");
        return pl != null && pl.isEnabled();
    }

    /** Bu oyuncu Bedrock'tan mi bagli? (diger eklentiler de bunu cagirabilir) */
    // © MRWQLF (EFEHAN KARACA) TARAFINDAN TELİFLİDİR
    public boolean isBedrock(UUID kimlik) {
        if (floodgateVar()) {
            try {
                Class<?> api = Class.forName("org.geysermc.floodgate.api.FloodgateApi");
                Object ornek = api.getMethod("getInstance").invoke(null);
                Object sonuc = api.getMethod("isFloodgatePlayer", UUID.class).invoke(ornek, kimlik);
                if (sonuc instanceof Boolean b) {
                    return b;
                }
            } catch (ReflectiveOperationException | RuntimeException ignored) {
                // UUID yontemine dus
            }
        }
        return kimlik.getMostSignificantBits() == 0L;
    }

    // ------------------------------------------------------------ giris

    @EventHandler
    // © MRWQLF (EFEHAN KARACA) TARAFINDAN TELİFLİDİR
    public void girdi(PlayerJoinEvent e) {
        Player p = e.getPlayer();
        if (!isBedrock(p.getUniqueId())) {
            return;
        }
        long gecikme = Math.max(1, getConfig().getLong("gecikme-tick", 40));
        Bukkit.getScheduler().runTaskLater(this, () -> {
            if (!p.isOnline()) {
                return;
            }
            if (getConfig().getBoolean("etiket-ver", true)) {
                p.addScoreboardTag(ETIKET);
            }
            for (String satir : getConfig().getStringList("karsilama")) {
                p.sendMessage(renkli(satir.replace("{oyuncu}", p.getName())));
            }
            for (String komut : getConfig().getStringList("giris-komutlari")) {
                String k = komut.replace("{oyuncu}", p.getName()).replace("{uuid}", p.getUniqueId().toString());
                if (k.startsWith("/")) {
                    k = k.substring(1);
                }
                if (!k.isBlank()) {
                    Bukkit.dispatchCommand(Bukkit.getConsoleSender(), k);
                }
            }
        }, gecikme);
    }

    // ------------------------------------------------------------ komut

    // © MRWQLF (EFEHAN KARACA) TARAFINDAN TELİFLİDİR
    private static Component renkli(String s) {
        return LegacyComponentSerializer.legacyAmpersand().deserialize(s);
    }

    @Override
    // © MRWQLF (EFEHAN KARACA) TARAFINDAN TELİFLİDİR
    public boolean onCommand(CommandSender gonderen, Command komut, String etiket, String[] args) {
        String alt = args.length == 0 ? "" : args[0].toLowerCase();
        switch (alt) {
            case "liste" -> {
                if (!gonderen.hasPermission("bedrockgiris.admin")) {
                    gonderen.sendMessage(renkli("&cBu komut sadece yetkililer içindir."));
                    return true;
                }
                List<String> adlar = new ArrayList<>();
                for (Player p : Bukkit.getOnlinePlayers()) {
                    if (isBedrock(p.getUniqueId())) {
                        adlar.add(p.getName());
                    }
                }
                gonderen.sendMessage(renkli("&8[&bBedrock&8] &7Çevrimiçi Bedrock oyuncusu: &f" + adlar.size()
                        + (adlar.isEmpty() ? "" : " &8- &f" + String.join("&7, &f", adlar))));
            }
            case "reload" -> {
                if (!gonderen.hasPermission("bedrockgiris.admin")) {
                    gonderen.sendMessage(renkli("&cBu komut sadece yetkililer içindir."));
                    return true;
                }
                reloadConfig();
                gonderen.sendMessage(renkli("&8[&bBedrock&8] &aAyarlar yeniden yüklendi."));
            }
            default -> {
                gonderen.sendMessage(renkli("&8[&bBedrock&8] &7Bedrock (telefon/konsol/Windows) ile bağlanmak için:"));
                gonderen.sendMessage(renkli("&7Adres: &f" + getConfig().getString("adres", "sunucu.ip.adresi")));
                gonderen.sendMessage(renkli("&7Port: &f" + getConfig().getInt("port", 19132)));
            }
        }
        return true;
    }

    @Override
    // © MRWQLF (EFEHAN KARACA) TARAFINDAN TELİFLİDİR
    public List<String> onTabComplete(CommandSender s, Command c, String l, String[] a) {
        List<String> aday = new ArrayList<>();
        if (a.length == 1 && s.hasPermission("bedrockgiris.admin")) {
            aday.add("liste");
            aday.add("reload");
        }
        return aday;
    }
}
// © MRWQLF (EFEHAN KARACA) TARAFINDAN TELİFLİDİR
